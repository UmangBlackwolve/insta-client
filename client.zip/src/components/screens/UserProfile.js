import React, { useEffect, useState, useContext } from "react";
import { UserContext } from "../../App";
import { useParams } from "react-router-dom";

const Profile = () => {
  const [userProfile, setUserProfile] = useState(null);
  const [error, setError] = useState(null);
  const { state, dispatch } = useContext(UserContext);
  const { userid } = useParams();

  useEffect(() => {
    fetch(`http://localhost:5000/user/${userid}`, {
      headers: {
        "Authorization": "Bearer " + localStorage.getItem("jwt")
      }
    })
      .then(res => {
        if (!res.ok) {
          throw new Error('User not found');
        }
        return res.json();
      })
      .then(result => {
        setUserProfile(result);
      })
      .catch(err => {
        setError(err.message);
      });
  }, [userid]);

  return (
    <>
      {error ? (
        <h2>{error}</h2>
      ) : (
        userProfile ? (
          <div style={{ maxWidth: "550px", margin: "0px auto" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-around",
                margin: "18px 0px",
                borderBottom: "1px solid grey",
              }}
            >
              <div>
                <img
                  style={{ width: "160px", height: "160px", borderRadius: "80px", objectFit: "cover" }}
                  src="https://i.pinimg.com/736x/f2/71/eb/f271eb7e6c3e29394797c4de29c752bf.jpg"
                  alt="Profile"
                />
              </div>
              <div>
                <h4>{userProfile.user.username}</h4>
                <h5>{userProfile.user.email}</h5>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    width: "108%",
                  }}
                >
                  <h5>{userProfile.posts ? userProfile.posts.length : 0} Posts</h5>
                  <h5>{userProfile.user.followers ? userProfile.user.followers.length : 0} Followers</h5>
                  <h5>{userProfile.user.following ? userProfile.user.following.length : 0} Following</h5>
                </div>
              </div>
            </div>

            <div className="gallery">
              {userProfile.posts && userProfile.posts.map(item => (
                <img key={item._id} className="item" src={item.pic} alt={item.title} />
              ))}
            </div>
          </div>
        ) : (
          <h2>Loading...!</h2>
        )
      )}
    </>
  );
};

export default Profile;
