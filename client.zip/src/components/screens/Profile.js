import React, { useEffect, useState , useContext } from "react";
import { UserContext } from "../../App";

const Profile = () => {
  const[mypics ,setMypics] = useState([])
  const {state , dispatch} = useContext(UserContext)

  useEffect(() => {
    fetch('http://localhost:5000/mypost', {
      headers: {
        "Authorization": "Bearer " + localStorage.getItem("jwt")
      }
    }).then(res => res.json())
      .then(result => {
        setMypics(result.mypost)
      })
  }, [])

  return (
    <div style={{ maxWidth: "550px", margin: "0px auto" }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-around",
          margin: "18px 0px",
          borderBottom: "1px solid grey",
        }}
      >
        <div>
          <img
            style={{ width: "160px", height: "160px", borderRadius: "80px" , objectFit: "cover" }}
            src="https://i.pinimg.com/736x/f2/71/eb/f271eb7e6c3e29394797c4de29c752bf.jpg"
          />
        </div>
        <div>
          <h4>{state ? state.name : "loading"}</h4>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "108%",
            }}
          >
            <h5>40 Post</h5>
            <h5>40 Followers</h5>
            <h5>40 Following</h5>
          </div>
        </div>
      </div>

      <div className="gallery">
       {
         mypics.map(item => {
           return (
             <img key={item._id} className="item" src={item.pic} alt={item.title} />
           )
         })
       }
      </div>
    </div>
  );
};

export default Profile;
